package com.viewnext.services;

import com.viewnext.models.Carrito;

public interface ICarritoServices {
	
	Carrito crear(String usuario);
	
	Carrito consultar(String usuario);
	
	Carrito agregarPedido(Long id, int cantidad, String usuario);
	
	Carrito eliminarPedido(Long id, String usuario);

}
