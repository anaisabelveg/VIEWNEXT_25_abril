package com.viewnext.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "CARRITOS", path = "carritos")
public interface CarritoDAO extends MongoRepository<Carrito, String>{
	
	// Tambien nos podemos crear nuestros propios metodos
	public Carrito findByUsuario(String usuario);

}
