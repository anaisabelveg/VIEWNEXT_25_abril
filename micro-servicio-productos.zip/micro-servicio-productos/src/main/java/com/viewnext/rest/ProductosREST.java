package com.viewnext.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.models.Producto;
import com.viewnext.services.IProductoService;

@RestController
public class ProductosREST {
	
	@Autowired
	private IProductoService productoService;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos();
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) {
		return productoService.buscarProducto(id);
	}

}
